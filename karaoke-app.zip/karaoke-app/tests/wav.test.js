import test from 'node:test';
import assert from 'node:assert/strict';
import { encodeWav } from '../www/js/wav.js';
import { demoLyrics } from '../www/js/demo.js';
import { parseLrc } from '../www/js/lrc.js';

test('encodeWav writes a valid 16-bit stereo header and samples', async () => {
  const L = Float32Array.from([0, 1, -1, 0.5]);
  const R = Float32Array.from([0, 0, 0, 0]);
  const blob = encodeWav({ numberOfChannels: 2, sampleRate: 44100, length: 4, getChannelData: (c) => (c ? R : L) });
  const v = new DataView(await blob.arrayBuffer());
  const tag = (o) => String.fromCharCode(v.getUint8(o), v.getUint8(o + 1), v.getUint8(o + 2), v.getUint8(o + 3));
  assert.equal(tag(0), 'RIFF');
  assert.equal(tag(8), 'WAVE');
  assert.equal(v.getUint32(4, true), 36 + 16);
  assert.equal(v.getUint16(22, true), 2);
  assert.equal(v.getUint32(24, true), 44100);
  assert.equal(v.getUint32(40, true), 16);
  assert.equal(v.byteLength, 44 + 16);
  assert.equal(v.getInt16(44 + 4, true), 32767);   // frame 1, left = +1
  assert.equal(v.getInt16(44 + 8, true), -32768);  // frame 2, left = -1
});

test('demo lyrics are valid, synced and ordered', () => {
  const { lines, meta } = parseLrc(demoLyrics());
  assert.equal(lines.length, 9);
  assert.equal(meta.ti, 'Kanta Tayo (Demo)');
  for (let i = 1; i < lines.length; i++) assert.ok(lines[i].time > lines[i - 1].time);
  assert.ok(lines.at(-1).time < 48);
});
