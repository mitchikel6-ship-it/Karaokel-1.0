// Smoke test for the Web Audio code using a mock AudioContext (no browser available in CI/sandbox).
// It cannot judge sound quality, but it catches wiring mistakes, typos and runtime exceptions.
import test from 'node:test';
import assert from 'node:assert/strict';

class Param {
  value = 0;
  setTargetAtTime() {}
  setValueAtTime() {}
  linearRampToValueAtTime() {}
  exponentialRampToValueAtTime() {}
}

const edges = [];
class MockNode {
  constructor(kind) {
    this.kind = kind;
    return new Proxy(this, {
      get(t, p) {
        if (p in t) return t[p];
        if (typeof p === 'symbol' || p === 'then') return undefined;
        return (t[p] = new Param()); // any AudioParam-like property
      },
    });
  }
  connect(to) {
    edges.push([this.kind, to?.kind ?? 'param']);
    return to;
  }
  disconnect() {}
  start() {}
  stop() {}
}

class MockCtx {
  sampleRate = 44100;
  currentTime = 0;
  state = 'suspended';
  destination = new MockNode('destination');
  async resume() {
    this.state = 'running';
  }
  createBuffer(ch, len) {
    const data = Array.from({ length: ch }, () => new Float32Array(len));
    return { numberOfChannels: ch, length: len, sampleRate: this.sampleRate, getChannelData: (c) => data[c] };
  }
}
for (const k of ['Gain', 'Delay', 'BiquadFilter', 'DynamicsCompressor', 'Convolver', 'BufferSource', 'ChannelSplitter', 'ChannelMerger', 'Oscillator', 'StereoPanner', 'MediaElementSource', 'MediaStreamSource', 'MediaStreamDestination']) {
  MockCtx.prototype[`create${k}`] = function () {
    const n = new MockNode(k);
    if (k === 'MediaStreamDestination') n.stream = {};
    return n;
  };
}
class MockOffline extends MockCtx {
  constructor(ch, length, sr) {
    super();
    this.ch = ch;
    this.length = length;
    this.sampleRate = sr;
  }
  async startRendering() {
    return this.createBuffer(this.ch, this.length);
  }
}

class MockAudio {
  listeners = {};
  paused = true;
  currentTime = 0;
  duration = 48;
  addEventListener(n, f) {
    (this.listeners[n] ??= []).push(f);
  }
  removeEventListener(n, f) {
    this.listeners[n] = (this.listeners[n] ?? []).filter((x) => x !== f);
  }
  load() {
    queueMicrotask(() => (this.listeners.loadedmetadata ?? []).slice().forEach((f) => f()));
  }
  pause() {
    this.paused = true;
  }
  async play() {
    this.paused = false;
  }
}

class MockRecorder {
  static isTypeSupported = (t) => t === 'audio/webm;codecs=opus';
  state = 'inactive';
  constructor(_stream, opts) {
    this.mimeType = opts?.mimeType ?? '';
  }
  start() {
    this.state = 'recording';
    queueMicrotask(() => this.ondataavailable?.({ data: new Blob(['x']) }));
  }
  stop() {
    this.state = 'inactive';
    queueMicrotask(() => this.onstop?.());
  }
}

globalThis.window = globalThis;
globalThis.AudioContext = MockCtx;
globalThis.OfflineAudioContext = MockOffline;
globalThis.Audio = MockAudio;
globalThis.MediaRecorder = MockRecorder;
Object.defineProperty(globalThis, 'navigator', {
  configurable: true,
  value: { mediaDevices: { getUserMedia: async () => ({ getTracks: () => [{ stop() {} }] }) } },
});

const { KaraokeEngine, extFor } = await import('../www/js/audio.js');
const { renderDemoInstrumental } = await import('../www/js/demo.js');

test('engine builds the graph, applies settings and loads audio', async () => {
  const e = new KaraokeEngine();
  e.apply({ key: 2, tempo: 0.9 }); // before the graph exists: must not throw
  assert.equal(e.audio.playbackRate, 0.9);
  await e.load(new Blob(['fake']));
  await e.ensure();
  assert.equal(e.ctx.state, 'running');
  e.apply({ key: -3, vocalCut: true, echo: 0.8, reverb: 0.5, monitor: false, musicVol: 0.4, micVol: 1.5 });
  e.apply({ key: 0, vocalCut: false });
  await e.play();
  assert.equal(e.paused, false);
  e.seek(1e9);
  assert.equal(e.currentTime, 48);
  e.seek(-5);
  assert.equal(e.currentTime, 0);
});

test('graph wiring: music and mic both reach speakers and the recorder', async () => {
  edges.length = 0;
  const e = new KaraokeEngine();
  await e.ensure();
  const has = (a, b) => edges.some(([x, y]) => x === a && y === b);
  assert.ok(has('MediaElementSource', 'Gain'));
  assert.ok(has('DynamicsCompressor', 'destination'));
  assert.ok(has('Gain', 'MediaStreamDestination'));
  assert.ok(has('Convolver', 'Gain'));
});

test('mic on/off and recording produce a blob', async () => {
  const e = new KaraokeEngine();
  await e.ensure();
  await e.enableMic();
  assert.equal(e.micOn, true);
  e.startRecording();
  assert.equal(e.recording, true);
  const blob = await e.stopRecording();
  assert.ok(blob instanceof Blob);
  assert.equal(e.recording, false);
  assert.equal(await e.stopRecording(), null);
  await e.disableMic();
  assert.equal(e.micOn, false);
});

test('extFor maps mime types', () => {
  assert.equal(extFor('audio/webm;codecs=opus'), 'webm');
  assert.equal(extFor('audio/mp4'), 'm4a');
  assert.equal(extFor('audio/ogg'), 'ogg');
});

test('demo instrumental renders to a WAV blob', async () => {
  const blob = await renderDemoInstrumental();
  assert.equal(blob.type, 'audio/wav');
  assert.ok(blob.size > 44);
});
