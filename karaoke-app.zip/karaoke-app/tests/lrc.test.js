import test from 'node:test';
import assert from 'node:assert/strict';
import { parseLrc, hasTimestamps, plainLines, activeIndex, lineFill, formatStamp, serializeLrc } from '../www/js/lrc.js';

test('parses basic LRC with meta, sorting and line ends', () => {
  const { lines, meta } = parseLrc('[ti:Song]\n[ar:Me]\n[00:10.50]second\n[00:02.5]first\n');
  assert.equal(meta.ti, 'Song');
  assert.equal(meta.ar, 'Me');
  assert.deepEqual(lines.map((l) => l.text), ['first', 'second']);
  assert.equal(lines[0].time, 2.5);
  assert.equal(lines[1].time, 10.5);
  assert.equal(lines[0].end, 10.5);
  assert.equal(lines[1].end, 15.5);
});

test('multiple time tags repeat the line (chorus)', () => {
  const { lines } = parseLrc('[00:05.00][01:05.00]chorus line');
  assert.equal(lines.length, 2);
  assert.equal(lines[1].time, 65);
  assert.equal(lines[1].text, 'chorus line');
});

test('offset tag shifts lyrics earlier and clamps at zero', () => {
  const { lines } = parseLrc('[offset:+500]\n[00:01.00]a\n[00:10.00]b');
  assert.equal(lines[0].time, 0.5);
  assert.equal(lines[1].time, 9.5);
});

test('ms-style and colon-fraction stamps', () => {
  const { lines } = parseLrc('[00:12.500]x\n[00:13:25]y');
  assert.equal(lines[0].time, 12.5);
  assert.equal(lines[1].time, 13.25);
});

test('handles CRLF, BOM and blank lines', () => {
  const { lines } = parseLrc('﻿[00:01.00]one\r\n\r\n[00:02.00]two\r\n');
  assert.equal(lines.length, 2);
});

test('enhanced word tags', () => {
  const { lines } = parseLrc('[00:10.00]<00:10.00>Hel<00:10.50>lo <00:11.00>world');
  assert.equal(lines[0].text, 'Hello world');
  assert.equal(lines[0].words.length, 3);
  assert.equal(lines[0].words[1].time, 10.5);
});

test('hasTimestamps / plainLines', () => {
  assert.equal(hasTimestamps('[00:01.00]hi'), true);
  assert.equal(hasTimestamps('just words\nmore words'), false);
  assert.equal(hasTimestamps('[Chorus]\nla la'), false);
  assert.deepEqual(plainLines('[Verse 1]\n one \n\n two\n[Chorus]'), ['one', 'two']);
});

test('activeIndex', () => {
  const { lines } = parseLrc('[00:05.00]a\n[00:10.00]b\n[00:20.00]c');
  assert.equal(activeIndex(lines, 0), -1);
  assert.equal(activeIndex(lines, 5), 0);
  assert.equal(activeIndex(lines, 9.99), 0);
  assert.equal(activeIndex(lines, 10), 1);
  assert.equal(activeIndex(lines, 999), 2);
  assert.equal(activeIndex([], 3), -1);
});

test('lineFill without word timing is monotonic and capped', () => {
  const { lines } = parseLrc('[00:10.00]hello there friend\n[00:30.00]next');
  const l = lines[0];
  assert.equal(lineFill(l, 9), 0);
  const a = lineFill(l, 11);
  const b = lineFill(l, 12);
  assert.ok(a > 0 && b > a && b <= 1);
  assert.equal(lineFill(l, 25), 1);
});

test('lineFill with word timing follows the words', () => {
  const { lines } = parseLrc('[00:10.00]<00:10.00>aaaa<00:12.00>bbbb\n[00:20.00]end');
  const l = lines[0];
  assert.equal(lineFill(l, 12), 0.5);
  assert.ok(Math.abs(lineFill(l, 12.5) - 0.75) < 1e-9); // last word "bbbb" lasts 1s
  assert.equal(lineFill(l, 13), 1);
  assert.equal(lineFill(l, 18), 1); // does not wait for the next line
});

test('formatStamp rounds and carries', () => {
  assert.equal(formatStamp(0), '00:00.00');
  assert.equal(formatStamp(65.5), '01:05.50');
  assert.equal(formatStamp(59.999), '01:00.00');
  assert.equal(formatStamp(-3), '00:00.00');
});

test('serialize round-trips', () => {
  const src = [{ time: 1.25, text: 'hello' }, { time: 70, text: 'world' }];
  const text = serializeLrc(src, { ti: 'T', ar: 'A' });
  const { lines, meta } = parseLrc(text);
  assert.equal(meta.ti, 'T');
  assert.deepEqual(lines.map((l) => [l.time, l.text]), [[1.25, 'hello'], [70, 'world']]);
});
