// Tiny IndexedDB wrapper: song info + lyrics in "songs", audio files in "audio".

let dbPromise;

function open() {
  dbPromise ??= new Promise((resolve, reject) => {
    const req = indexedDB.open('karaoke', 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore('songs', { keyPath: 'id' });
      req.result.createObjectStore('audio');
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

const wrap = (req) =>
  new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });

async function tx(stores, mode, fn) {
  const db = await open();
  const t = db.transaction(stores, mode);
  const done = new Promise((resolve, reject) => {
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
  });
  const out = await fn(t);
  await done;
  return out;
}

const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

export async function addSong(meta, audioBlob) {
  const song = { id: newId(), createdAt: Date.now(), title: '', artist: '', lyrics: '', ...meta };
  await tx(['songs', 'audio'], 'readwrite', (t) => {
    t.objectStore('songs').put(song);
    t.objectStore('audio').put(audioBlob, song.id);
  });
  return song;
}

export async function listSongs() {
  const all = await tx('songs', 'readonly', (t) => wrap(t.objectStore('songs').getAll()));
  return all.sort((a, b) => b.createdAt - a.createdAt);
}

export const getSong = (id) => tx('songs', 'readonly', (t) => wrap(t.objectStore('songs').get(id)));
export const getAudio = (id) => tx('audio', 'readonly', (t) => wrap(t.objectStore('audio').get(id)));
export const updateSong = (song) => tx('songs', 'readwrite', (t) => wrap(t.objectStore('songs').put(song)));

export async function deleteSong(id) {
  await tx(['songs', 'audio'], 'readwrite', (t) => {
    t.objectStore('songs').delete(id);
    t.objectStore('audio').delete(id);
  });
}
