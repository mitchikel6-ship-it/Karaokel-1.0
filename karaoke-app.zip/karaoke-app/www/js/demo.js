// Built-in demo song: an ORIGINAL instrumental synthesised in code (so there is nothing
// copyrighted in the app) plus original lyrics, so the app works the moment it is installed.

import { encodeWav } from './wav.js';
import { serializeLrc } from './lrc.js';

export const DEMO_TITLE = 'Kanta Tayo (Demo)';

const BPM = 100;
const BEAT = 60 / BPM;
const BAR = BEAT * 4; // one chord per bar
const BARS = 20; // 48 seconds
const LINE_START = BAR; // first line comes in after one bar of intro
const LINE_STEP = BAR * 2;

const LYRICS = [
  'Kanta tayo, kahit di perfect ang boses',
  'Basta masaya, walang pakialam sa mundo',
  'Ilaw ay mahina, pero puso ay maliwanag',
  'Tara na, sabay-sabay, isigaw natin ito',
  'Oh-oh-oh, kantahan natin ang gabi',
  'Hawak ang mic, kumakabog ang dibdib',
  'Walang mali sa tono kapag tayo ay magkasama',
  'Isa pa, isa pa, huwag muna tayong umuwi',
  'Kanta tayo, hanggang umaga',
];

export function demoLyrics() {
  const lines = LYRICS.map((text, i) => ({ time: LINE_START + i * LINE_STEP, text }));
  return serializeLrc(lines, { ti: DEMO_TITLE, ar: 'Original demo track' });
}

// C - G - Am - F
const CHORDS = [
  { notes: [261.63, 329.63, 392.0], root: 65.41 },
  { notes: [196.0, 246.94, 293.66], root: 98.0 },
  { notes: [220.0, 261.63, 329.63], root: 110.0 },
  { notes: [174.61, 220.0, 261.63], root: 87.31 },
];

export async function renderDemoInstrumental() {
  const OAC = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  const sr = 44100;
  const ctx = new OAC(2, Math.ceil((BARS * BAR + 1.5) * sr), sr);

  const master = ctx.createGain();
  master.gain.value = 0.9;
  const comp = ctx.createDynamicsCompressor();
  master.connect(comp);
  comp.connect(ctx.destination);

  const noise = ctx.createBuffer(1, sr, sr);
  const nd = noise.getChannelData(0);
  for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;

  const env = (g, t, peak, attack, hold, release) => {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + attack);
    g.gain.setValueAtTime(peak, t + attack + hold);
    g.gain.exponentialRampToValueAtTime(0.0001, t + attack + hold + release);
  };

  const pad = (chord, t) => {
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 1800;
    lp.connect(master);
    chord.notes.forEach((f, i) => {
      for (const detune of [-6, 6]) {
        const o = ctx.createOscillator();
        o.type = 'triangle';
        o.frequency.value = f;
        o.detune.value = detune;
        const g = ctx.createGain();
        const pan = ctx.createStereoPanner();
        pan.pan.value = (i - 1) * 0.5;
        env(g, t, 0.05, 0.15, BAR - 0.35, 0.3);
        o.connect(g);
        g.connect(pan);
        pan.connect(lp);
        o.start(t);
        o.stop(t + BAR + 0.5);
      }
    });
  };

  const bass = (chord, t) => {
    for (let n = 0; n < 8; n++) {
      const at = t + n * (BEAT / 2);
      if (n % 2 === 1 && n !== 3 && n !== 7) continue; // syncopated pattern
      const o = ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.value = chord.root;
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 380;
      const g = ctx.createGain();
      env(g, at, 0.32, 0.01, BEAT * 0.25, BEAT * 0.3);
      o.connect(lp);
      lp.connect(g);
      g.connect(master);
      o.start(at);
      o.stop(at + BEAT);
    }
  };

  const kick = (t) => {
    const o = ctx.createOscillator();
    o.frequency.setValueAtTime(150, t);
    o.frequency.exponentialRampToValueAtTime(45, t + 0.12);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.9, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
    o.connect(g);
    g.connect(master);
    o.start(t);
    o.stop(t + 0.4);
  };

  const noiseHit = (t, type, freq, peak, dur) => {
    const s = ctx.createBufferSource();
    s.buffer = noise;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(peak, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f);
    f.connect(g);
    g.connect(master);
    s.start(t);
    s.stop(t + dur + 0.05);
  };

  for (let b = 0; b < BARS; b++) {
    const t0 = b * BAR;
    const chord = CHORDS[b % CHORDS.length];
    pad(chord, t0);
    bass(chord, t0);
    for (let h = 0; h < 8; h++) noiseHit(t0 + h * (BEAT / 2), 'highpass', 7000, h % 2 ? 0.1 : 0.16, 0.05);
    if (b >= 1) {
      kick(t0);
      kick(t0 + BEAT * 2);
      noiseHit(t0 + BEAT, 'bandpass', 1800, 0.4, 0.18);
      noiseHit(t0 + BEAT * 3, 'bandpass', 1800, 0.4, 0.18);
    }
  }

  const rendered = await ctx.startRendering();
  return encodeWav(rendered);
}
