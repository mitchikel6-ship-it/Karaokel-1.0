// Dependency-free real-time pitch shifter (two crossfaded, sawtooth-modulated delay lines).
// Changes the KEY of the music without changing its speed. Sounds clean for about +/-6 semitones.

const BUF = 0.1; // seconds per modulation cycle

function rampBuffer(ctx, up) {
  const len = Math.round(BUF * ctx.sampleRate);
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const p = buf.getChannelData(0);
  for (let i = 0; i < len; i++) p[i] = up ? (len - i) / len : i / len;
  return buf;
}

function fadeBuffer(ctx) {
  const len = Math.round(BUF * ctx.sampleRate);
  const half = Math.round(len / 2);
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const p = buf.getChannelData(0);
  for (let i = 0; i < len; i++) {
    p[i] = i < half ? Math.sqrt(i / half) : Math.sqrt(1 - (i - half) / (len - half));
  }
  return buf;
}

export class PitchShifter {
  constructor(ctx) {
    this.ctx = ctx;
    this.input = ctx.createGain();
    this.output = ctx.createGain();
    this.dry = ctx.createGain();
    this.wet = ctx.createGain();
    this.wet.gain.value = 0;
    this.input.connect(this.dry);
    this.dry.connect(this.output);
    this.wet.connect(this.output);

    const down = rampBuffer(ctx, false);
    const up = rampBuffer(ctx, true);
    const fade = fadeBuffer(ctx);
    const start = ctx.currentTime + 0.05;
    this.taps = [];

    for (let k = 0; k < 2; k++) {
      const at = start + k * (BUF / 2);
      const delay = ctx.createDelay(1);
      const depth = ctx.createGain(); // scales the 0..1 ramp into a delay time (seconds)
      const downSrc = ctx.createBufferSource();
      const upSrc = ctx.createBufferSource();
      downSrc.buffer = down;
      upSrc.buffer = up;
      downSrc.loop = true;
      upSrc.loop = true;
      const downSel = ctx.createGain();
      const upSel = ctx.createGain();
      upSel.gain.value = 0;
      downSrc.connect(downSel);
      upSrc.connect(upSel);
      downSel.connect(depth);
      upSel.connect(depth);
      depth.connect(delay.delayTime);

      const fadeSrc = ctx.createBufferSource();
      fadeSrc.buffer = fade;
      fadeSrc.loop = true;
      const win = ctx.createGain();
      win.gain.value = 0;
      fadeSrc.connect(win.gain);

      this.input.connect(delay);
      delay.connect(win);
      win.connect(this.wet);

      downSrc.start(at);
      upSrc.start(at);
      fadeSrc.start(at);
      this.taps.push({ depth, downSel, upSel });
    }
  }

  /** Shift the key by n semitones (0 = bypass). */
  setSemitones(n) {
    const t = this.ctx.currentTime;
    if (!n) {
      this.dry.gain.setTargetAtTime(1, t, 0.02);
      this.wet.gain.setTargetAtTime(0, t, 0.02);
      return;
    }
    const ratio = 2 ** (n / 12);
    const amount = Math.abs(ratio - 1) * BUF;
    for (const tap of this.taps) {
      tap.depth.gain.value = amount;
      tap.downSel.gain.value = ratio < 1 ? 1 : 0;
      tap.upSel.gain.value = ratio > 1 ? 1 : 0;
    }
    this.dry.gain.setTargetAtTime(0, t, 0.02);
    this.wet.gain.setTargetAtTime(1, t, 0.02);
  }
}
