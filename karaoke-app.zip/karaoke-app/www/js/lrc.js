// LRC parsing / serialising and the helpers used by the lyrics view and the sync editor.
// Supports: [mm:ss.xx] line tags, several tags per line (repeated choruses),
// [ti:] [ar:] [offset:] meta tags, and enhanced word tags like <00:12.50>.

const NUM = String.raw`\d{1,3}:\d{2}(?:[.:]\d{1,3})?`;
const LINE_RE = new RegExp(String.raw`^((?:\[${NUM}\])+)(.*)$`);
const ONE_RE = new RegExp(String.raw`\[(${NUM})\]`, 'g');
const WORD_SPLIT_RE = new RegExp(String.raw`<(${NUM})>`);
const META_RE = /^\[([A-Za-z]+):(.*)\]$/;

function stampToSeconds(str) {
  const i = str.indexOf(':');
  const minutes = Number(str.slice(0, i));
  const rest = Number(str.slice(i + 1).replace(':', '.'));
  return minutes * 60 + rest;
}

function splitWords(body, lineTime) {
  if (!WORD_SPLIT_RE.test(body)) return { text: body, words: null };
  const parts = body.split(WORD_SPLIT_RE); // [pre, stamp, text, stamp, text, ...]
  const words = [];
  if (parts[0]) words.push({ time: lineTime, text: parts[0] });
  for (let i = 1; i < parts.length; i += 2) {
    const text = parts[i + 1] ?? '';
    if (text) words.push({ time: stampToSeconds(parts[i]), text });
  }
  return { text: words.map((w) => w.text).join('').trim(), words: words.length ? words : null };
}

export function hasTimestamps(text) {
  return String(text ?? '')
    .split(/\r?\n/)
    .some((row) => LINE_RE.test(row.trim()));
}

/** Lines of plain lyrics (one per row). Section labels like [Chorus] are dropped. */
export function plainLines(text) {
  return String(text ?? '')
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter((s) => s && !/^\[[^\]]*\]$/.test(s));
}

export function parseLrc(text) {
  const meta = {};
  const out = [];
  const source = String(text ?? '').replace(/^﻿/, '');
  for (const raw of source.split(/\r?\n/)) {
    const row = raw.trim();
    if (!row) continue;
    const m = LINE_RE.exec(row);
    if (m) {
      const times = [...m[1].matchAll(ONE_RE)].map((x) => stampToSeconds(x[1]));
      const { text: body, words } = splitWords(m[2].trim(), times[0]);
      for (const t of times) {
        const delta = t - times[0];
        out.push({
          time: t,
          text: body,
          words: words ? words.map((w) => ({ time: w.time + delta, text: w.text })) : null,
        });
      }
      continue;
    }
    const mm = META_RE.exec(row);
    if (mm) meta[mm[1].toLowerCase()] = mm[2].trim();
  }

  const shift = (Number(meta.offset) || 0) / 1000; // positive offset = lyrics appear sooner
  if (shift) {
    for (const l of out) {
      l.time = Math.max(0, l.time - shift);
      if (l.words) for (const w of l.words) w.time = Math.max(0, w.time - shift);
    }
  }

  out.sort((a, b) => a.time - b.time);
  out.forEach((l, i) => {
    const next = out[i + 1];
    l.end = Math.max(next ? next.time : l.time + 5, l.time + 0.01);
  });
  return { lines: out, meta };
}

/** Index of the line being sung at time t (-1 before the first line). */
export function activeIndex(lines, t) {
  let lo = 0;
  let hi = lines.length - 1;
  let ans = -1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (lines[mid].time <= t) {
      ans = mid;
      lo = mid + 1;
    } else hi = mid - 1;
  }
  return ans;
}

/** 0..1: how much of the line has been sung at time t (drives the colour fill). */
export function lineFill(line, t) {
  if (!line || t <= line.time) return 0;
  if (line.words && line.words.length) {
    const total = line.words.reduce((n, w) => n + w.text.length, 0) || 1;
    let done = 0;
    for (let i = 0; i < line.words.length; i++) {
      const w = line.words[i];
      // The last word must not stretch across a long instrumental gap to the next line.
      const wEnd = line.words[i + 1]
        ? line.words[i + 1].time
        : Math.min(line.end, w.time + Math.max(0.6, w.text.length * 0.25));
      if (t >= wEnd) {
        done += w.text.length;
        continue;
      }
      if (t > w.time) done += (w.text.length * (t - w.time)) / Math.max(0.05, wEnd - w.time);
      break;
    }
    return Math.min(1, done / total);
  }
  // No word timing: spread the fill over a sensible singing time for this line.
  const span = Math.max(0.5, Math.min(line.end - line.time, Math.max(1.2, line.text.length * 0.22)));
  return Math.min(1, (t - line.time) / span);
}

const pad = (n) => String(n).padStart(2, '0');

export function formatStamp(sec) {
  const cs = Math.round(Math.max(0, sec) * 100);
  const m = Math.floor(cs / 6000);
  const s = Math.floor((cs % 6000) / 100);
  return `${pad(m)}:${pad(s)}.${pad(cs % 100)}`;
}

export function serializeLrc(lines, meta = {}) {
  const head = [];
  if (meta.ti) head.push(`[ti:${meta.ti}]`);
  if (meta.ar) head.push(`[ar:${meta.ar}]`);
  const body = lines.map((l) => `[${formatStamp(l.time)}]${l.text}`);
  return [...head, ...body].join('\n') + '\n';
}
