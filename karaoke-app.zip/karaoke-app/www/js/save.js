// Save / share a recording. In the Android app this opens the share sheet (save to Files,
// send to Messenger, etc.). In a browser it uses Web Share if available, else a download.

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1] ?? '');
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

export async function saveOrShare(blob, filename) {
  const cap = window.Capacitor;
  if (cap?.isNativePlatform?.()) {
    const { Filesystem, Share } = cap.Plugins;
    const data = await blobToBase64(blob);
    const res = await Filesystem.writeFile({ path: filename, data, directory: 'CACHE' });
    await Share.share({ title: filename, url: res.uri, dialogTitle: 'I-save o ibahagi ang recording' });
    return 'shared';
  }

  const file = new File([blob], filename, { type: blob.type });
  if (navigator.canShare?.({ files: [file] })) {
    try {
      await navigator.share({ files: [file], title: filename });
      return 'shared';
    } catch (e) {
      if (e?.name === 'AbortError') return 'cancelled';
    }
  }
  const url = URL.createObjectURL(blob);
  const a = Object.assign(document.createElement('a'), { href: url, download: filename });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
  return 'downloaded';
}
