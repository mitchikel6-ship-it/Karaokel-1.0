// Karaoke audio engine (Web Audio).
//
//  music file -> [vocal reducer] -> key shifter -> music fader -+-> speakers (via limiter)
//  mic -> hi-pass -> mic fader -> compressor -> dry/echo/reverb -+-> speakers (if "hear myself")
//                                                                +-> recorder (music + voice)

import { PitchShifter } from './pitch.js';

const PRESERVE = ['preservesPitch', 'webkitPreservesPitch', 'mozPreservesPitch'];

function makeImpulse(ctx, seconds = 2.2, decay = 3) {
  const len = Math.round(ctx.sampleRate * seconds);
  const buf = ctx.createBuffer(2, len, ctx.sampleRate);
  for (let c = 0; c < 2; c++) {
    const d = buf.getChannelData(c);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len) ** decay;
  }
  return buf;
}

export function extFor(mime = '') {
  if (mime.includes('mp4')) return 'm4a';
  if (mime.includes('ogg')) return 'ogg';
  if (mime.includes('wav')) return 'wav';
  return 'webm';
}

export class KaraokeEngine {
  constructor() {
    this.ctx = null;
    this.audio = new Audio();
    this.audio.preload = 'auto';
    this.settings = {
      musicVol: 0.85,
      micVol: 1,
      echo: 0.25,
      reverb: 0.3,
      tempo: 1,
      key: 0,
      vocalCut: false,
      headphones: true,
      monitor: true,
    };
    this.micStream = null;
    this.micSrc = null;
    this.recorder = null;
    this.chunks = [];
    this.url = null;
  }

  get micOn() {
    return !!this.micSrc;
  }
  get recording() {
    return !!this.recorder && this.recorder.state === 'recording';
  }
  get currentTime() {
    return this.audio.currentTime || 0;
  }
  get duration() {
    return Number.isFinite(this.audio.duration) ? this.audio.duration : 0;
  }
  get paused() {
    return this.audio.paused;
  }

  async ensure() {
    if (!this.ctx) this._build();
    if (this.ctx.state === 'suspended') await this.ctx.resume();
  }

  _build() {
    const AC = window.AudioContext || window.webkitAudioContext;
    const ctx = (this.ctx = new AC({ latencyHint: 'interactive' }));
    const gain = () => ctx.createGain();

    // --- music: normal path and "vocal reducer" path (L minus R cancels centre-panned vocals)
    const src = ctx.createMediaElementSource(this.audio);
    this.direct = gain();
    this.cut = gain();
    this.cut.gain.value = 0;
    const split = ctx.createChannelSplitter(2);
    const merge = ctx.createChannelMerger(2);
    const left = gain();
    const right = gain();
    right.gain.value = -1;
    src.connect(this.direct);
    src.connect(split);
    split.connect(left, 0);
    split.connect(right, 1);
    for (const n of [left, right]) {
      n.connect(merge, 0, 0);
      n.connect(merge, 0, 1);
    }
    merge.connect(this.cut);

    this.pitch = new PitchShifter(ctx);
    this.direct.connect(this.pitch.input);
    this.cut.connect(this.pitch.input);
    this.musicGain = gain();
    this.pitch.output.connect(this.musicGain);

    // --- microphone chain
    this.micIn = gain();
    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 90;
    this.micVol = gain();
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -24;
    comp.ratio.value = 3;
    this.micBus = gain();
    this.micIn.connect(hp);
    hp.connect(this.micVol);
    this.micVol.connect(comp);
    comp.connect(this.micBus); // dry voice

    this.echoSend = gain();
    this.delay = ctx.createDelay(1);
    this.delay.delayTime.value = 0.3;
    const echoLp = ctx.createBiquadFilter();
    echoLp.type = 'lowpass';
    echoLp.frequency.value = 3200;
    this.fb = gain();
    comp.connect(this.echoSend);
    this.echoSend.connect(this.delay);
    this.delay.connect(echoLp);
    echoLp.connect(this.fb);
    this.fb.connect(this.delay); // feedback loop (contains a DelayNode, so it is legal)
    echoLp.connect(this.micBus);

    this.revSend = gain();
    const conv = ctx.createConvolver();
    conv.buffer = makeImpulse(ctx);
    comp.connect(this.revSend);
    this.revSend.connect(conv);
    conv.connect(this.micBus);

    // --- outputs
    const speakers = gain();
    const limiter = ctx.createDynamicsCompressor();
    limiter.threshold.value = -3;
    limiter.knee.value = 0;
    limiter.ratio.value = 12;
    limiter.attack.value = 0.003;
    this.monitor = gain();
    this.musicGain.connect(speakers);
    this.micBus.connect(this.monitor);
    this.monitor.connect(speakers);
    speakers.connect(limiter);
    limiter.connect(ctx.destination);

    this.recDest = ctx.createMediaStreamDestination();
    const recMix = gain();
    this.musicGain.connect(recMix);
    this.micBus.connect(recMix);
    recMix.connect(this.recDest);

    this.apply({});
  }

  /** Update any of the mixer settings. Safe to call before the audio graph exists. */
  apply(patch = {}) {
    const s = (this.settings = { ...this.settings, ...patch });
    const a = this.audio;
    a.playbackRate = s.tempo;
    for (const k of PRESERVE) if (k in a) a[k] = true;
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const set = (param, v) => param.setTargetAtTime(v, t, 0.02);
    set(this.musicGain.gain, s.musicVol);
    set(this.micVol.gain, s.micVol);
    set(this.echoSend.gain, s.echo);
    set(this.fb.gain, 0.15 + 0.4 * s.echo);
    set(this.revSend.gain, s.reverb * 1.2);
    set(this.monitor.gain, s.monitor ? 1 : 0);
    set(this.direct.gain, s.vocalCut ? 0 : 1);
    set(this.cut.gain, s.vocalCut ? 1 : 0);
    this.pitch.setSemitones(s.key);
  }

  load(blob) {
    this.audio.pause();
    if (this.url) URL.revokeObjectURL(this.url);
    this.url = URL.createObjectURL(blob);
    this.audio.src = this.url;
    return new Promise((resolve, reject) => {
      const clean = () => {
        this.audio.removeEventListener('loadedmetadata', ok);
        this.audio.removeEventListener('error', bad);
      };
      const ok = () => {
        clean();
        resolve();
      };
      const bad = () => {
        clean();
        reject(new Error('Hindi mabasa ang audio file.'));
      };
      this.audio.addEventListener('loadedmetadata', ok);
      this.audio.addEventListener('error', bad);
      this.audio.load();
    });
  }

  async play() {
    await this.ensure();
    return this.audio.play();
  }
  pause() {
    this.audio.pause();
  }
  seek(t) {
    const max = this.duration || t;
    this.audio.currentTime = Math.max(0, Math.min(max, t));
  }

  async enableMic() {
    await this.ensure();
    await this.disableMic();
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: !this.settings.headphones,
        noiseSuppression: false,
        autoGainControl: false,
      },
    });
    this.micStream = stream;
    this.micSrc = this.ctx.createMediaStreamSource(stream);
    this.micSrc.connect(this.micIn);
  }

  async disableMic() {
    if (this.micSrc) this.micSrc.disconnect();
    if (this.micStream) this.micStream.getTracks().forEach((t) => t.stop());
    this.micSrc = null;
    this.micStream = null;
  }

  startRecording() {
    const types = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'];
    const mimeType = types.find((t) => window.MediaRecorder && MediaRecorder.isTypeSupported(t));
    this.recorder = new MediaRecorder(this.recDest.stream, mimeType ? { mimeType } : undefined);
    this.chunks = [];
    this.recorder.ondataavailable = (e) => {
      if (e.data && e.data.size) this.chunks.push(e.data);
    };
    this.recorder.start(250);
  }

  stopRecording() {
    const r = this.recorder;
    if (!r || r.state === 'inactive') return Promise.resolve(null);
    return new Promise((resolve) => {
      r.onstop = () => {
        const blob = new Blob(this.chunks, { type: r.mimeType || 'audio/webm' });
        this.recorder = null;
        this.chunks = [];
        resolve(blob);
      };
      r.stop();
    });
  }
}
