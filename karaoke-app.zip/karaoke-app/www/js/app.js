import { KaraokeEngine, extFor } from './audio.js';
import * as db from './db.js';
import { parseLrc, hasTimestamps, plainLines, serializeLrc, activeIndex, lineFill } from './lrc.js';
import { renderDemoInstrumental, demoLyrics, DEMO_TITLE } from './demo.js';
import { saveOrShare } from './save.js';

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const clock = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

const engine = new KaraokeEngine();

// ---------------------------------------------------------------- settings
const DEFAULTS = { musicVol: 0.85, micVol: 1, echo: 0.25, reverb: 0.3, tempo: 1, key: 0, vocalCut: false,
  headphones: true, monitor: true, offsetMs: 0 };
const PER_SONG = { key: 0, tempo: 1, vocalCut: false };

function loadSettings() {
  try {
    return { ...DEFAULTS, ...JSON.parse(localStorage.getItem('karaoke.settings') || '{}'), ...PER_SONG };
  } catch {
    return { ...DEFAULTS };
  }
}
function saveSettings() {
  try {
    localStorage.setItem('karaoke.settings', JSON.stringify(settings));
  } catch { /* storage unavailable: fine */ }
}
let settings = loadSettings();
engine.apply(settings);

// ---------------------------------------------------------------- state
let songs = [];
let current = null; // song currently loaded into the engine
let lines = [];
let timed = false;
let lyricEls = [];
let lastIdx = -2;
let screen = 'library';
let editor = null;
let recStart = 0;
let takeUrl = null;
let takeBlob = null;

let toastTimer;
function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 3500);
}

function show(name) {
  screen = name;
  $$('.screen').forEach((el) => el.classList.toggle('active', el.id === `screen-${name}`));
}

// ---------------------------------------------------------------- library
const lyricsBadge = (s) =>
  !s.lyrics ? 'walang lyrics' : hasTimestamps(s.lyrics) ? 'synced lyrics ✓' : 'lyrics (walang timing)';

async function refreshLibrary() {
  songs = await db.listSongs();
  const list = $('#song-list');
  list.replaceChildren();
  $('#empty').classList.toggle('hidden', songs.length > 0);
  for (const s of songs) {
    const row = document.createElement('div');
    row.className = 'song';
    row.innerHTML = `<button class="song-main"><span class="song-title"></span><span class="song-sub"></span></button>
      <button class="icon" data-act="edit" aria-label="Lyrics">✎</button>
      <button class="icon danger" data-act="del" aria-label="Burahin">🗑</button>`;
    $('.song-title', row).textContent = s.title;
    $('.song-sub', row).textContent = [s.artist, lyricsBadge(s)].filter(Boolean).join(' · ');
    $('.song-main', row).onclick = () => openPlayer(s.id);
    $('[data-act=edit]', row).onclick = () => openEditor(s.id);
    $('[data-act=del]', row).onclick = async () => {
      if (!confirm(`Burahin ang "${s.title}"?`)) return;
      await db.deleteSong(s.id);
      if (current?.id === s.id) {
        engine.pause();
        current = null;
      }
      refreshLibrary();
    };
    list.append(row);
  }
}

$('#btn-add').onclick = () => {
  $('#form-add').reset();
  $('#modal-add').classList.remove('hidden');
};
$('#add-cancel').onclick = () => $('#modal-add').classList.add('hidden');
$('#form-add').onsubmit = async (e) => {
  e.preventDefault();
  const form = e.target;
  const audio = form.audio.files[0];
  if (!audio) return;
  try {
    let lyrics = form.lyrics.value.trim();
    const lrcFile = form.lrcfile.files[0];
    if (lrcFile) lyrics = (await lrcFile.text()).trim();
    const guess = audio.name.replace(/\.[^.]+$/, '');
    await db.addSong(
      { title: form.title.value.trim() || guess, artist: form.artist.value.trim(), lyrics },
      audio,
    );
    $('#modal-add').classList.add('hidden');
    await refreshLibrary();
    toast(lyrics ? 'Naidagdag ang kanta!' : 'Naidagdag. Pindutin ang ✎ para maglagay ng lyrics.');
  } catch (err) {
    toast(`Hindi ma-save: ${err.message || err}`);
  }
};

async function seedDemo() {
  try {
    if (localStorage.getItem('karaoke.demo')) return;
  } catch { /* ignore */ }
  toast('Ginagawa ang demo song…');
  const blob = await renderDemoInstrumental();
  await db.addSong({ title: DEMO_TITLE, artist: 'Original demo track', lyrics: demoLyrics() }, blob);
  try {
    localStorage.setItem('karaoke.demo', '1');
  } catch { /* ignore */ }
}

// ---------------------------------------------------------------- loading a song
async function loadSong(id) {
  const song = songs.find((s) => s.id === id) || (await db.getSong(id));
  if (!song) throw new Error('Wala na ang kantang ito.');
  if (!current || current.id !== id) {
    const blob = await db.getAudio(id);
    if (!blob) throw new Error('Nawawala ang audio file ng kantang ito.');
    await engine.ensure();
    await engine.load(blob);
    Object.assign(settings, PER_SONG);
    engine.apply(settings);
  }
  current = song;
  return song;
}

function setupLyrics(song) {
  const box = $('#lyrics');
  box.replaceChildren();
  lyricEls = [];
  lastIdx = -2;
  const text = song.lyrics || '';
  timed = hasTimestamps(text);
  lines = timed
    ? parseLrc(text).lines
    : plainLines(text).map((t, i) => ({ time: i, end: i + 1, text: t, words: null }));
  const hint = $('#sync-hint');
  hint.classList.toggle('hidden', timed);
  hint.textContent = text
    ? 'Walang timing ang lyrics. Pindutin ang ✎ at “I-sync gamit tap”.'
    : 'Wala pang lyrics. Pindutin ang ✎ para magdagdag.';
  for (const l of lines) {
    const d = document.createElement('div');
    d.className = timed ? 'ly' : 'ly plain';
    d.textContent = l.text || '♪';
    box.append(d);
    lyricEls.push(d);
  }
  box.scrollTop = 0;
}

async function openPlayer(id) {
  try {
    const song = await loadSong(id);
    setupLyrics(song);
    syncMixerUI();
    syncPlayBtn();
    syncMicBtn();
    $('#player-title').textContent = song.title;
    $('#player-artist').textContent = song.artist || '';
    $('#take').classList.add('hidden');
    show('player');
  } catch (err) {
    toast(err.message || String(err));
  }
}

// ---------------------------------------------------------------- player UI
function syncPlayBtn() {
  const playing = !engine.paused;
  const b = $('#btn-play');
  b.textContent = playing ? '⏸' : '▶';
  b.setAttribute('aria-label', playing ? 'Pause' : 'Play');
  $('#sync-play').textContent = playing ? '⏸' : '▶';
}
['play', 'pause', 'ended'].forEach((ev) => engine.audio.addEventListener(ev, syncPlayBtn));
engine.audio.addEventListener('ended', () => {
  if (engine.recording) stopRec();
});

function syncMicBtn() {
  $('#btn-mic').classList.toggle('on', engine.micOn);
}

async function togglePlay() {
  try {
    if (engine.paused) await engine.play();
    else engine.pause();
  } catch (err) {
    toast(`Hindi ma-play: ${err.message || err}`);
  }
}

async function tryEnableMic() {
  try {
    await engine.enableMic();
    return true;
  } catch {
    toast('Hindi mabuksan ang mic. Payagan ang Microphone permission sa Settings.');
    return false;
  }
}

async function toggleMic() {
  if (engine.micOn) await engine.disableMic();
  else if (!(await tryEnableMic())) return;
  syncMicBtn();
}

async function startRec() {
  if (!engine.micOn && !(await tryEnableMic())) return;
  syncMicBtn();
  if (takeUrl) URL.revokeObjectURL(takeUrl);
  takeUrl = takeBlob = null;
  $('#take').classList.add('hidden');
  engine.startRecording();
  recStart = performance.now();
  $('#btn-rec').classList.add('rec');
  if (engine.paused) await togglePlay();
}

async function stopRec() {
  const blob = await engine.stopRecording();
  $('#btn-rec').classList.remove('rec');
  $('#btn-rec').textContent = '⏺';
  if (!blob || !blob.size) return toast('Walang na-record.');
  takeBlob = blob;
  takeUrl = URL.createObjectURL(blob);
  $('#take-audio').src = takeUrl;
  $('#take').classList.remove('hidden');
}

$('#btn-back').onclick = () => {
  if (engine.recording) stopRec();
  engine.pause();
  $('#mixer').classList.add('hidden');
  show('library');
};
$('#btn-edit').onclick = () => current && openEditor(current.id);
$('#btn-play').onclick = togglePlay;
$('#btn-restart').onclick = () => engine.seek(0);
$('#btn-mic').onclick = toggleMic;
$('#btn-rec').onclick = () => (engine.recording ? stopRec() : startRec());
$('#btn-mixer').onclick = () => $('#mixer').classList.toggle('hidden');
$('#mixer-close').onclick = () => $('#mixer').classList.add('hidden');
let seeking = false; // true while the finger is on the slider, so the frame loop does not fight it
const seekEl = $('#seek');
seekEl.addEventListener('pointerdown', () => (seeking = true));
['pointerup', 'pointercancel', 'change'].forEach((ev) => seekEl.addEventListener(ev, () => (seeking = false)));
seekEl.addEventListener('input', (e) => engine.seek(Number(e.target.value)));
$('#take-discard').onclick = () => {
  $('#take').classList.add('hidden');
  $('#take-audio').removeAttribute('src');
  if (takeUrl) URL.revokeObjectURL(takeUrl);
  takeUrl = takeBlob = null;
};
$('#take-save').onclick = async () => {
  if (!takeBlob) return;
  const stamp = new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '');
  const name = `${(current?.title || 'karaoke').replace(/[^\w\- ]+/g, '').trim() || 'karaoke'}-${stamp}.${extFor(takeBlob.type)}`;
  try {
    const how = await saveOrShare(takeBlob, name);
    if (how === 'downloaded') toast('Na-download ang recording.');
  } catch (err) {
    toast(`Hindi ma-save: ${err.message || err}`);
  }
};

// ---------------------------------------------------------------- mixer
const SLIDERS = [
  { id: 'musicVol', label: 'Music', min: 0, max: 1, step: 0.01, fmt: (v) => `${Math.round(v * 100)}%` },
  { id: 'micVol', label: 'Mic', min: 0, max: 2, step: 0.01, fmt: (v) => `${Math.round(v * 100)}%` },
  { id: 'echo', label: 'Echo', min: 0, max: 1, step: 0.01, fmt: (v) => `${Math.round(v * 100)}%` },
  { id: 'reverb', label: 'Reverb', min: 0, max: 1, step: 0.01, fmt: (v) => `${Math.round(v * 100)}%` },
  { id: 'tempo', label: 'Bilis', min: 0.7, max: 1.3, step: 0.05, fmt: (v) => `${v.toFixed(2)}×` },
];

function buildMixer() {
  const box = $('#sliders');
  for (const s of SLIDERS) {
    const row = document.createElement('label');
    row.className = 'row';
    row.innerHTML = `<span>${s.label}</span><input type="range" min="${s.min}" max="${s.max}" step="${s.step}"><output></output>`;
    const input = $('input', row);
    input.dataset.id = s.id;
    input.oninput = () => {
      settings[s.id] = Number(input.value);
      $('output', row).textContent = s.fmt(settings[s.id]);
      engine.apply({ [s.id]: settings[s.id] });
      saveSettings();
    };
    box.append(row);
  }

  const step = (key, delta, lo, hi) => {
    settings[key] = clamp(settings[key] + delta, lo, hi);
    engine.apply({ [key]: settings[key] });
    saveSettings();
    syncMixerUI();
  };
  $('#key-down').onclick = () => step('key', -1, -6, 6);
  $('#key-up').onclick = () => step('key', 1, -6, 6);
  $('#off-down').onclick = () => step('offsetMs', -50, -2000, 2000);
  $('#off-up').onclick = () => step('offsetMs', 50, -2000, 2000);

  $('#tg-vocal').onchange = (e) => {
    settings.vocalCut = e.target.checked;
    engine.apply({ vocalCut: settings.vocalCut });
  };
  $('#tg-monitor').onchange = (e) => {
    settings.monitor = e.target.checked;
    engine.apply({ monitor: settings.monitor });
    saveSettings();
  };
  $('#tg-phones').onchange = async (e) => {
    settings.headphones = e.target.checked;
    if (!settings.headphones) settings.monitor = false; // avoid speaker -> mic feedback
    engine.apply({ headphones: settings.headphones, monitor: settings.monitor });
    saveSettings();
    syncMixerUI();
    if (engine.micOn) await tryEnableMic(); // restart mic with the right echo-cancel mode
  };
}

function syncMixerUI() {
  for (const s of SLIDERS) {
    const input = $(`#sliders input[data-id="${s.id}"]`);
    input.value = settings[s.id];
    input.nextElementSibling.textContent = s.fmt(settings[s.id]);
  }
  $('#key-val').textContent = `${settings.key > 0 ? '+' : ''}${settings.key}`;
  $('#off-val').textContent = `${settings.offsetMs > 0 ? '+' : ''}${settings.offsetMs} ms`;
  $('#tg-vocal').checked = settings.vocalCut;
  $('#tg-phones').checked = settings.headphones;
  $('#tg-monitor').checked = settings.monitor;
}

// ---------------------------------------------------------------- lyrics editor
async function openEditor(id) {
  try {
    const song = await loadSong(id);
    editor = { song, syncing: false, lines: [], stamps: [], idx: 0 };
    $('#ed-title').textContent = song.title;
    $('#ed-text').value = song.lyrics || '';
    $('#ed-edit').classList.remove('hidden');
    $('#ed-sync-pane').classList.add('hidden');
    engine.pause();
    show('editor');
  } catch (err) {
    toast(err.message || String(err));
  }
}

async function saveLyrics(text) {
  const song = editor.song;
  song.lyrics = text.trim();
  await db.updateSong(song);
  const i = songs.findIndex((s) => s.id === song.id);
  if (i >= 0) songs[i] = song;
}

function renderSync() {
  const { lines: ls, idx } = editor;
  $('#sync-prev').textContent = idx > 0 ? ls[idx - 1] : '';
  $('#sync-now').textContent = idx < ls.length ? ls[idx] : '✓ Tapos na ang lahat ng linya';
  $('#sync-next').textContent = idx + 1 < ls.length ? ls[idx + 1] : '';
  $('#sync-count').textContent = `${idx}/${ls.length}`;
}

function updateSyncClock() {
  $('#sync-clock').textContent = `${clock(engine.currentTime)}.${Math.floor((engine.currentTime % 1) * 10)}`;
}

$('#ed-back').onclick = () => {
  engine.pause();
  refreshLibrary();
  show('library');
};
$('#ed-save').onclick = async () => {
  await saveLyrics($('#ed-text').value);
  toast('Na-save ang lyrics.');
  await refreshLibrary();
  openPlayer(editor.song.id);
};
$('#ed-sync').onclick = async () => {
  const text = $('#ed-text').value;
  const ls = hasTimestamps(text) ? parseLrc(text).lines.map((l) => l.text).filter(Boolean) : plainLines(text);
  if (!ls.length) return toast('Maglagay muna ng lyrics.');
  Object.assign(editor, { syncing: true, lines: ls, stamps: [], idx: 0 });
  $('#ed-edit').classList.add('hidden');
  $('#ed-sync-pane').classList.remove('hidden');
  renderSync();
  engine.seek(0);
  await togglePlay();
};
$('#sync-tap').onclick = () => {
  if (!editor.syncing || editor.idx >= editor.lines.length) return;
  editor.stamps[editor.idx] = Math.max(0, engine.currentTime - 0.12); // allow for reaction time
  editor.idx++;
  renderSync();
  if (navigator.vibrate) navigator.vibrate(15);
};
$('#sync-undo').onclick = () => {
  if (editor.idx === 0) return;
  editor.idx--;
  const t = editor.stamps[editor.idx];
  editor.stamps.length = editor.idx;
  engine.seek(Math.max(0, t - 2));
  renderSync();
};
$('#sync-back3').onclick = () => engine.seek(engine.currentTime - 3);
$('#sync-play').onclick = togglePlay;
$('#sync-done').onclick = async () => {
  const { lines: ls, stamps, idx, song } = editor;
  if (idx === 0) return toast('Wala ka pang na-tap na linya.');
  if (idx < ls.length && !confirm(`May ${ls.length - idx} linya pang walang timing. Itutuloy pa rin?`)) return;
  engine.pause();
  const timedLines = ls.slice(0, idx).map((text, i) => ({ time: stamps[i], text }));
  editor.syncing = false;
  await saveLyrics(serializeLrc(timedLines, { ti: song.title, ar: song.artist }));
  toast('Na-sync ang lyrics!');
  await refreshLibrary();
  openPlayer(song.id);
};

// ---------------------------------------------------------------- frame loop
function updatePlayer() {
  const cur = engine.currentTime;
  const dur = engine.duration;
  const seek = $('#seek');
  if (!seeking) {
    seek.max = dur || 1;
    seek.value = cur;
  }
  $('#t-cur').textContent = clock(cur);
  $('#t-dur').textContent = clock(dur);
  if (engine.recording) {
    const s = Math.floor((performance.now() - recStart) / 1000);
    $('#btn-rec').textContent = `⏹ ${clock(s)}`;
  }
  if (!timed) return;

  const t = cur + settings.offsetMs / 1000;
  const idx = activeIndex(lines, t);
  if (idx !== lastIdx) {
    lastIdx = idx;
    lyricEls.forEach((el, i) => {
      el.classList.toggle('active', i === idx);
      el.classList.toggle('past', i < idx);
      if (i !== idx) el.style.removeProperty('--p');
    });
    (lyricEls[idx] ?? lyricEls[0])?.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
  if (idx >= 0) lyricEls[idx].style.setProperty('--p', `${(lineFill(lines[idx], t) * 100).toFixed(1)}%`);
}

function tick() {
  requestAnimationFrame(tick);
  if (screen === 'player') updatePlayer();
  else if (screen === 'editor' && editor?.syncing) updateSyncClock();
}

// ---------------------------------------------------------------- boot
buildMixer();
syncMixerUI();
requestAnimationFrame(tick);

(async () => {
  try {
    await seedDemo();
  } catch (err) {
    toast(`Hindi nagawa ang demo song: ${err.message || err}`);
  }
  await refreshLibrary();
})();

if ('serviceWorker' in navigator && location.protocol.startsWith('http') && !window.Capacitor?.isNativePlatform?.()) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
