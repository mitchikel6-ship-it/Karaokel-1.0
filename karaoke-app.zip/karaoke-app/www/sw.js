// Minimal offline cache for the web/PWA (iPhone "Add to Home Screen"). Network first, so updates always win.
const CACHE = 'karaoke-v1';
const FILES = ['./', 'index.html', 'css/style.css', 'manifest.webmanifest', 'js/app.js', 'js/audio.js', 'js/pitch.js',
  'js/lrc.js', 'js/db.js', 'js/demo.js', 'js/wav.js', 'js/save.js', 'icons/icon-192.png', 'icons/icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    fetch(e.request)
      .then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(e.request, copy));
        return res;
      })
      .catch(() => caches.match(e.request)),
  );
});
