# 🎤 Karaoke

Karaoke app para sa phone. **Lyrics ang pinakamahalaga**: may synced na lyrics na nagkukulay habang kinakanta, at may sariling tool para i-sync ang kahit anong lyrics gamit lang ang pag-tap.

## Mga feature

- **Synced lyrics** (`.lrc`, kasama ang word-by-word na `<00:12.50>`), may fill na gumagalaw habang kumakanta
- **Lyrics sync maker**: i-paste ang lyrics, tumutugtog ang kanta, i-TAP sa simula ng bawat linya
- **Mic** na may **echo** at **reverb** (headphones inirerekomenda)
- **Key change** (±6 semitones) at **bilis** (0.7×–1.3×) nang hindi nagbabago ang isa
- **Vocal reducer** para sa stereo na kanta na may boses
- **Recording** (boses + music), may share/save
- Lahat ng kanta ay naka-save sa phone mo (offline)
- May kasamang **demo song** na gawa sa code (original, walang copyright) para gumana agad

## Paano makuha ang APK (Android)

1. Gumawa ng GitHub repo at i-upload ang laman ng folder na ito.
2. Sa terminal: `git tag v0.1.0 && git push --tags`
   (o sa GitHub: **Actions → Build Android APK → Run workflow**)
3. Hintayin ~5–8 minuto. Ang **Karaoke.apk** ay lalabas sa **Releases** (o sa Artifacts ng run).
4. I-download sa phone → i-install (payagan ang "Install unknown apps").
5. Pagbukas, payagan ang **Microphone**.

> Debug-signed ang APK, installable at okay para sa personal/pagsubok. Para sa Play Store, kailangan ng release keystore.

## iPhone

Walang libreng paraan para mag-install ng native app sa iPhone nang walang Mac at Apple Developer account ($99/taon). Pero gumagana ang web version:

1. Repo **Settings → Pages → Source: GitHub Actions**.
2. Pag-push sa `main`, madi-deploy ang web app (workflow na `pages.yml`).
3. Sa iPhone, buksan ang link sa **Safari → Share → Add to Home Screen**.

## Paano gamitin

1. **＋ Kanta** → piliin ang instrumental/audio, ilagay ang pamagat, at lyrics (`.lrc` file, o i-paste).
2. Kung plain lyrics lang: pindutin ang ✎ → **I-sync gamit tap**.
3. Buksan ang kanta → 🎤 para sa mic, ⏺ para mag-record, 🎚 para sa mixer.
4. Kung nauuna o nahuhuli ang lyrics, ayusin ang **Timing ng lyrics** sa mixer.

## Saan kukuha ng royalty-free na instrumental

Siguraduhing **basahin ang license** ng bawat track (may nangangailangan ng credit):
Pixabay Music, YouTube Audio Library, Free Music Archive, Mixkit, Incompetech. Hindi kasama sa app ang anumang copyrighted na kanta o ang sounds ng Megapro.

## Development

```bash
npm test          # unit tests: lyrics parser, WAV encoder, audio-engine wiring (walang browser)
npm run serve     # http://localhost:8080 para subukan sa Chrome (mic ay gumagana sa localhost)
npm run icons     # i-regenerate ang icons
```

Walang build step ang web app (plain ES modules sa `www/`). Capacitor ay ginagamit lang ng GitHub Actions para gawing APK.

## Istruktura

```
www/              ang app (HTML/CSS/JS)
  js/lrc.js       LRC parser, fill/active-line logic
  js/audio.js     mic, echo, reverb, key shift, vocal reducer, recording
  js/pitch.js     real-time pitch shifter
  js/demo.js      demo song generator
  js/app.js       UI
tests/            node:test
.github/workflows android.yml (APK) · pages.yml (web/iPhone)
```

Palitan ang pangalan ng app sa `capacitor.config.json` (`appName`) at sa `www/index.html`/`manifest.webmanifest`.
