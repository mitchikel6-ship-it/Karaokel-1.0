// Generates the app icon (a microphone on a purple→pink gradient) as PNGs, with no dependencies.
// Output: assets/icon.png (1024, used for the Android launcher icon) and www/icons/*.png (PWA / iPhone).
import { deflateSync } from 'node:zlib';
import { mkdirSync, writeFileSync } from 'node:fs';

const CRC = new Uint32Array(256).map((_, n) => {
  let c = n;
  for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  return c >>> 0;
});
const crc32 = (buf) => {
  let c = 0xffffffff;
  for (const b of buf) c = CRC[(c ^ b) & 255] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
};
const chunk = (type, data) => {
  const body = Buffer.concat([Buffer.from(type), data]);
  const out = Buffer.alloc(8 + data.length + 4);
  out.writeUInt32BE(data.length, 0);
  body.copy(out, 4);
  out.writeUInt32BE(crc32(body), 8 + data.length);
  return out;
};

const sdSegment = (px, py, ax, ay, bx, by) => {
  const dx = bx - ax;
  const dy = by - ay;
  const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)));
  return Math.hypot(px - ax - t * dx, py - ay - t * dy);
};
const sdBox = (px, py, cx, cy, hx, hy) => {
  const dx = Math.abs(px - cx) - hx;
  const dy = Math.abs(py - cy) - hy;
  return Math.hypot(Math.max(dx, 0), Math.max(dy, 0)) + Math.min(Math.max(dx, dy), 0);
};

function micDistance(u, v) {
  const capsule = sdSegment(u, v, 0.5, 0.31, 0.5, 0.45) - 0.105;
  const cradle = Math.max(Math.abs(Math.hypot(u - 0.5, v - 0.45) - 0.185) - 0.022, 0.45 - v);
  const stem = sdBox(u, v, 0.5, 0.7, 0.017, 0.05);
  const base = sdBox(u, v, 0.5, 0.76, 0.1, 0.018) - 0.006;
  return Math.min(capsule, cradle, stem, base);
}

function png(size) {
  const row = size * 4 + 1;
  const raw = Buffer.alloc(row * size);
  const c1 = [0x7c, 0x5c, 0xff];
  const c2 = [0xff, 0x4f, 0xa3];
  for (let y = 0; y < size; y++) {
    raw[y * row] = 0;
    for (let x = 0; x < size; x++) {
      const u = (x + 0.5) / size;
      const v = (y + 0.5) / size;
      const k = (u + v) / 2;
      const cover = Math.max(0, Math.min(1, 0.5 - micDistance(u, v) * size));
      const o = y * row + 1 + x * 4;
      for (let i = 0; i < 3; i++) {
        const bg = c1[i] + (c2[i] - c1[i]) * k;
        raw[o + i] = Math.round(bg + (255 - bg) * cover);
      }
      raw[o + 3] = 255;
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

mkdirSync('assets', { recursive: true });
mkdirSync('www/icons', { recursive: true });
writeFileSync('assets/icon.png', png(1024));
writeFileSync('www/icons/icon-512.png', png(512));
writeFileSync('www/icons/icon-192.png', png(192));
writeFileSync('www/icons/apple-touch-icon.png', png(180));
console.log('icons written');
